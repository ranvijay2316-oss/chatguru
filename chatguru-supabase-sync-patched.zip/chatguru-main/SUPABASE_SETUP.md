# ChatGuru: Supabase shared-login and shared-data setup

This patch changes staff authentication from browser-only demo credentials to Supabase Auth and stores the shared dashboard workspace in Supabase.

## 1. Create Supabase project
Create a project at https://supabase.com/dashboard.

## 2. Run the schema
Open SQL Editor and run `supabase/schema.sql`.

## 3. Create the owner account
In Authentication -> Users, create your owner login with email/password.
Copy its UUID. In SQL Editor run:

```sql
insert into public.staff_profiles (user_id, name, email, username, role, active)
values ('PASTE_OWNER_UUID', 'Owner', 'owner@example.com', 'owner', 'super_admin', true);
```

Replace the UUID and email with the actual values.

## 4. Create staff accounts
For each staff member:
1. Authentication -> Users -> Add user.
2. Create an individual email/password account.
3. Copy the new user's UUID.
4. Insert a profile, choosing `support_agent` or `marketing_manager`:

```sql
insert into public.staff_profiles (user_id, name, email, username, role, active)
values ('PASTE_STAFF_UUID', 'Staff Name', 'staff@example.com', 'staffname', 'support_agent', true);
```

Do not put passwords in the staff_profiles table or frontend.

## 5. Configure Netlify
In Netlify -> Site configuration -> Environment variables, add:
- `VITE_SUPABASE_URL` = Supabase Project URL
- `VITE_SUPABASE_ANON_KEY` = Supabase publishable key (or legacy anon key)

Do not add `service_role` or secret keys to Vite variables. They are public in a browser build.

Redeploy after setting environment variables.

## 6. Local development
Copy `.env.example` to `.env.local` and fill in the two VITE_ variables.
Then run:
```bash
npm install
npm run dev
```

## 7. First migration of old local data
Sign in to the new deployed website as the owner **from the browser that currently contains the old Local Storage records**.
If the shared `app_state` row does not exist, the app will copy that browser's existing settings, customers, messages, broadcasts and analytics into Supabase once.
The Telegram bot token is deliberately excluded from the cloud copy. It must be moved to a server-side function before production.

After the owner migration succeeds, sign in from staff browsers. They will load the same shared records.

If the owner has data in more than one browser, export/back up each browser first and merge those records before relying on the shared database. This one-time automatic migration only reads the owner browser's local cache.

## Important limitations / production hardening
- The app currently stores the workspace as one JSONB document. It synchronizes staff views, but simultaneous edits can overwrite each other. For a large or busy team, migrate to normalized tables with per-record updates.
- Supabase Realtime must be enabled for `public.app_state` (Database -> Replication).
- The Telegram API token is currently used by existing frontend Telegram API code. This patch excludes it from shared cloud state but does not yet move every Telegram API call behind a server-side function. Do not treat this as production-secure until that work is completed; rotate the bot token if it has been exposed in a deployed browser.
- Existing bot webhook/polling code runs in the browser. A single server-side webhook/worker should own Telegram updates in production; multiple staff browsers should not poll `getUpdates`.
- The legacy local cache remains as a backup/migration source; cloud state is the shared source of truth after sign-in.
- Test on a staging deployment and take a backup before switching production staff to the new build.
