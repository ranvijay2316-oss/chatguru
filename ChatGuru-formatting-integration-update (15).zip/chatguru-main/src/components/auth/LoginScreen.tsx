import React, { useState } from 'react';
import {
  Lock, User, Eye, EyeOff, ArrowRight, AlertCircle, Bot
} from 'lucide-react';
import { StaffMember, StaffRole } from '../../types';
import { supabase } from '../../services/supabase';

interface LoginScreenProps {
  staffList: StaffMember[];
  onLoginSuccess: (staff: StaffMember, rememberMe: boolean) => void;
  botName?: string;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess, botName }) => {
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: emailInput.trim().toLowerCase(),
        password: passwordInput,
      });
      if (error || !data.user) throw new Error(error?.message || 'Login failed');

      const { data: profile, error: profileError } = await supabase
        .from('staff_profiles')
        .select('user_id, name, email, username, role, active, phone')
        .eq('user_id', data.user.id)
        .single();

      if (profileError || !profile || !profile.active) {
        await supabase.auth.signOut();
        throw new Error('This account is not authorized or has been deactivated. Contact your administrator.');
      }

      const role = profile.role as StaffRole;
      const staff: StaffMember = {
        id: profile.user_id,
        name: profile.name || data.user.email || 'Staff',
        email: profile.email || data.user.email || '',
        username: profile.username || (data.user.email || '').split('@')[0],
        role,
        phone: profile.phone || '',
        active: profile.active,
        assignedChatsCount: 0,
        lastLoginAt: new Date().toLocaleString(),
        avatarUrl: '',
      };
      onLoginSuccess(staff, rememberMe);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Unable to sign in.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-slate-800 to-sky-950 text-slate-900 select-none">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        <div className="bg-gradient-to-r from-sky-600 via-sky-700 to-indigo-800 p-6 text-white text-center">
          <div className="w-14 h-14 rounded-2xl bg-white/15 border border-white/25 flex items-center justify-center mx-auto mb-3">
            <Bot className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-xl font-black tracking-tight text-white">{botName || 'ChatGuru Admin Suite'}</h2>
          <p className="text-xs text-sky-100 font-medium mt-1">Secure staff sign-in</p>
        </div>
        <div className="p-6 sm:p-8 space-y-5">
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl text-rose-800 text-xs font-bold flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <p className="flex-1 leading-snug">{errorMessage}</p>
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs font-black text-slate-900 block mb-1.5 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-sky-600" /> Email address
              </label>
              <input
                type="email" required autoComplete="username"
                value={emailInput} onChange={(e) => setEmailInput(e.target.value)}
                placeholder="name@company.com"
                className="w-full text-xs font-bold px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 text-slate-900"
              />
            </div>
            <div>
              <label className="text-xs font-black text-slate-900 block mb-1.5 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-sky-600" /> Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'} required autoComplete="current-password"
                  value={passwordInput} onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full text-xs font-bold pl-3.5 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 text-slate-900"
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-700">
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700">
              <input type="checkbox" checked={rememberMe} onChange={(e) => setRememberMe(e.target.checked)}
                className="w-4 h-4 rounded text-sky-600 border-slate-300" />
              Remember me on this browser
            </label>
            <button type="submit" disabled={isLoading}
              className="w-full py-3 bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white rounded-xl text-xs font-black flex items-center justify-center gap-2 shadow-md">
              {isLoading ? 'Authenticating...' : <>Sign In to Dashboard <ArrowRight className="w-4 h-4" /></>}
            </button>
          </form>
          <p className="text-[11px] leading-relaxed text-slate-500 text-center">
            Staff accounts are provisioned by your administrator. There are no shared demo credentials.
          </p>
        </div>
      </div>
    </div>
  );
};
