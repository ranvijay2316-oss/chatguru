import React from 'react';
import { Shield, Users, UserCheck, Info } from 'lucide-react';
import { StaffMember } from '../../types';

interface StaffPanelProps {
  staffList: StaffMember[];
  currentStaff: StaffMember;
  onSelectStaff: (staff: StaffMember) => void;
  onUpdateStaffList: (staffList: StaffMember[]) => void;
}

export const StaffPanel: React.FC<StaffPanelProps> = ({ staffList, currentStaff }) => {
  const roleLabel = (role: string) => ({
    super_admin: 'Super Admin',
    support_agent: 'Support Agent',
    marketing_manager: 'Marketing Manager',
  }[role] || role);

  return (
    <div className="space-y-6 text-slate-900">
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <Shield className="w-4 h-4 text-sky-600" />
          <span className="text-xs font-bold text-sky-800 uppercase tracking-wider">Centralized staff access</span>
        </div>
        <h2 className="text-lg font-extrabold">Employees &amp; Staff</h2>
        <p className="text-xs text-slate-600 mt-1">
          Staff identities and passwords are managed by Supabase Authentication, not browser storage.
        </p>
      </div>

      <div className="bg-sky-50 border border-sky-200 rounded-xl p-4 flex gap-3">
        <Info className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" />
        <div className="text-xs text-sky-950 leading-relaxed">
          <strong>Create or invite staff in Supabase:</strong> Authentication → Users → Add user.
          Then add a matching row in <code>public.staff_profiles</code> with that user's UUID and
          one of these roles: <code>super_admin</code>, <code>support_agent</code>, or
          <code>marketing_manager</code>. Never store or display staff passwords in this dashboard.
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Users className="w-5 h-5 text-sky-600" />
          <h3 className="font-extrabold text-sm">Authorized staff accounts</h3>
        </div>
        {staffList.length === 0 ? (
          <p className="text-xs text-slate-500">No staff profiles were returned. Check the staff_profiles table and its Row Level Security policies.</p>
        ) : (
          <div className="space-y-2">
            {staffList.map((staff) => (
              <div key={staff.id} className="flex items-center justify-between gap-3 border border-slate-200 rounded-lg p-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold">
                    {(staff.name || 'S').charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold truncate">{staff.name} {staff.id === currentStaff.id ? '(You)' : ''}</div>
                    <div className="text-[11px] text-slate-500 truncate">{staff.email}</div>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-[11px] font-bold">{roleLabel(staff.role)}</div>
                  <div className={`text-[10px] ${staff.active ? 'text-emerald-700' : 'text-rose-700'}`}>
                    {staff.active ? 'Active' : 'Inactive'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <div className="flex items-center gap-2 mb-2">
          <UserCheck className="w-4 h-4 text-emerald-600" />
          <h3 className="font-extrabold text-sm">How to add a staff member</h3>
        </div>
        <ol className="list-decimal pl-5 text-xs text-slate-700 space-y-1">
          <li>Create the staff account under Supabase Authentication → Users.</li>
          <li>Copy the new user's UUID.</li>
          <li>Insert a staff_profiles row using that UUID and the correct role.</li>
          <li>Ask the staff member to sign in using their own email and password.</li>
        </ol>
      </div>
    </div>
  );
};
