import React, { useState, useEffect, useRef } from 'react';
import {
  storage,
  CLEAN_SETTINGS,
  INITIAL_MESSAGES,
  INITIAL_USERS,
  INITIAL_BROADCASTS,
  INITIAL_ANALYTICS,
} from './services/storage';
import { telegramApi } from './services/telegramApi';
import {
  BotSettings,
  ChatMessage,
  UserSubscriber,
  BroadcastCampaign,
  ClickAnalytics,
  InlineButtonConfig,
  StaffMember,
  InteractionNotification,
} from './types';
import { TelegramSimulator } from './components/telegram/TelegramSimulator';
import { AdminSidebar, AdminTab } from './components/admin/AdminSidebar';
import { AdminHeader } from './components/admin/AdminHeader';
import { NotificationPopup } from './components/admin/NotificationPopup';
import { OverviewTab } from './components/admin/OverviewTab';
import { BotBuilderTab } from './components/admin/BotBuilderTab';
import { CrmUsersTab } from './components/admin/CrmUsersTab';
import { BroadcastTab, BroadcastResult, BroadcastDeliveryLog } from './components/admin/BroadcastTab';
import { AnalyticsTab } from './components/admin/AnalyticsTab';
import { TelegramApiTab } from './components/admin/TelegramApiTab';
import { StaffPanel } from './components/admin/StaffPanel';
import { LoginScreen } from './components/auth/LoginScreen';
import { sound } from './services/sound';
import { supabase } from './services/supabase';
import { Smartphone, LayoutDashboard, Layers, X, Sparkles } from 'lucide-react';

export default function App() {
  // Authentication State
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [cloudReady, setCloudReady] = useState<boolean>(false);
  const skipCloudWriteRef = useRef<boolean>(false);

  // State
  const [settings, setSettings] = useState<BotSettings>(() => storage.getSettings());
  const [messages, setMessages] = useState<ChatMessage[]>(() => storage.getMessages());
  const [users, setUsers] = useState<UserSubscriber[]>(() => storage.getUsers());
  const [broadcasts, setBroadcasts] = useState<BroadcastCampaign[]>(() => storage.getBroadcasts());
  const [analytics, setAnalytics] = useState<ClickAnalytics[]>(() => storage.getAnalytics());
  const [staffList, setStaffList] = useState<StaffMember[]>([]);
  const [currentStaff, setCurrentStaff] = useState<StaffMember>(() => storage.getCurrentStaff());

  const [currentTab, setCurrentTab] = useState<AdminTab>('overview');
  const [viewMode, setViewMode] = useState<'split' | 'admin-only' | 'bot-only'>('split');
  const [selectedUserForChat, setSelectedUserForChat] = useState<UserSubscriber | null>(null);
  const [isBotTyping, setIsBotTyping] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Bot Interaction Notifications
  const [activePopupNotification, setActivePopupNotification] = useState<InteractionNotification | null>(null);
  const [notificationsHistory, setNotificationsHistory] = useState<InteractionNotification[]>([]);

  // Global persistent Telegram bot polling listener
  const lastUpdateIdRef = useRef<number>(Number(localStorage.getItem('chatguru_last_update_id') || 0));
  const pollInFlightRef = useRef<boolean>(false);
  const processedUpdateIdsRef = useRef<Set<number>>(new Set());
  const usersRef = useRef<UserSubscriber[]>(users);
  const messagesRef = useRef<ChatMessage[]>(messages);
  const [isTelegramPolling, setIsTelegramPolling] = useState(false);
  const [desktopNotificationsEnabled, setDesktopNotificationsEnabled] = useState<boolean>(typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted');
  const [telegramLogs, setTelegramLogs] = useState<Array<{ id: string; time: string; text: string; type: 'info' | 'message' | 'callback' }>>([]);


  // Authenticate staff centrally and hydrate the shared workspace from Supabase.
  useEffect(() => {
    let alive = true;

    const applyPayload = (payload: any) => {
      if (!payload) return;
      skipCloudWriteRef.current = true;
      if (payload.settings) {
        const localToken = storage.getSettings()?.profile?.token || '';
        setSettings({
          ...payload.settings,
          profile: { ...payload.settings.profile, token: localToken },
        });
      }
      if (Array.isArray(payload.messages)) setMessages(payload.messages);
      if (Array.isArray(payload.users)) setUsers(payload.users);
      if (Array.isArray(payload.broadcasts)) setBroadcasts(payload.broadcasts);
      if (Array.isArray(payload.analytics)) setAnalytics(payload.analytics);
      
    };

    const loadSession = async (session: any) => {
      if (!alive) return;
      setCloudReady(false);
      if (!session?.user) {
        setIsLoggedIn(false);
        setAuthLoading(false);
        return;
      }

      const { data: profile, error: profileError } = await supabase
        .from('staff_profiles')
        .select('user_id, name, email, username, role, active, phone')
        .eq('user_id', session.user.id)
        .single();

      if (!alive) return;
      if (profileError || !profile || !profile.active) {
        await supabase.auth.signOut();
        setIsLoggedIn(false);
        setAuthLoading(false);
        showToast('This account is not authorized or has been deactivated.');
        return;
      }

      const mapStaff = (row: any): StaffMember => ({
        id: row.user_id,
        name: row.name || row.email || 'Staff',
        email: row.email || '',
        username: row.username || (row.email || '').split('@')[0],
        role: row.role,
        phone: row.phone || '',
        active: !!row.active,
        assignedChatsCount: 0,
        lastLoginAt: new Date().toLocaleString(),
        avatarUrl: '',
      });

      const current = mapStaff(profile);
      setCurrentStaff(current);
      setIsLoggedIn(true);

      const { data: staffRows } = await supabase
        .from('staff_profiles')
        .select('user_id, name, email, username, role, active, phone')
        .order('name');
      if (alive && staffRows) setStaffList(staffRows.map(mapStaff));

      const { data: stateRow, error: stateError } = await supabase
        .from('app_state')
        .select('payload')
        .eq('id', 1)
        .maybeSingle();

      if (!alive) return;
      if (stateError) {
        console.error('Unable to load shared app state:', stateError.message);
        showToast('Could not load shared data. Check Supabase setup and RLS policies.');
        setAuthLoading(false);
        return;
      }

      if (stateRow?.payload) {
        applyPayload(stateRow.payload);
      } else if (profile.role === 'super_admin') {
        // One-time migration: the first owner login uploads this browser's local cache.
        const localSettings = storage.getSettings();
        const localPayload = {
          settings: {
            ...localSettings,
            profile: { ...localSettings.profile, token: '' },
          },
          messages: storage.getMessages(),
          users: storage.getUsers(),
          broadcasts: storage.getBroadcasts(),
          analytics: storage.getAnalytics(),
        };
        const { error: seedError } = await supabase
          .from('app_state')
          .upsert({ id: 1, payload: localPayload, updated_by: session.user.id });
        if (seedError) {
          console.error('Initial cloud migration failed:', seedError.message);
          showToast('Could not migrate local data. Check app_state permissions.');
        } else {
          applyPayload(localPayload);
          showToast('Your existing browser data has been copied to the shared database.');
        }
      } else {
        applyPayload({
          settings: CLEAN_SETTINGS,
          messages: INITIAL_MESSAGES,
          users: INITIAL_USERS,
          broadcasts: INITIAL_BROADCASTS,
          analytics: INITIAL_ANALYTICS,
        });
      }

      if (!alive) return;
      setCloudReady(true);
      setAuthLoading(false);
    };

    supabase.auth.getSession().then(({ data }) => loadSession(data.session));
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      window.setTimeout(() => { void loadSession(session); }, 0);
    });

    return () => {
      alive = false;
      authListener.subscription.unsubscribe();
    };
  }, []);

  // Persist one shared workspace record. Supabase is the source of truth; Local Storage is only a cache.
  useEffect(() => {
    if (!cloudReady || !isLoggedIn) return;
    if (skipCloudWriteRef.current) { skipCloudWriteRef.current = false; return; }
    const timer = window.setTimeout(async () => {
      const { data: authData } = await supabase.auth.getUser();
      if (!authData.user) return;
      const sharedSettings = {
        ...settings,
        // Telegram bot tokens must be moved to a server-side function before production.
        profile: { ...settings.profile, token: '' },
      };
      const payload = { settings: sharedSettings, messages, users, broadcasts, analytics };
      const { error } = await supabase
        .from('app_state')
        .upsert({ id: 1, payload, updated_by: authData.user.id });
      if (error) console.error('Cloud save failed:', error.message);
    }, 700);
    return () => window.clearTimeout(timer);
  }, [cloudReady, isLoggedIn, settings, messages, users, broadcasts, analytics]);

  // Receive changes made by another signed-in staff member.
  useEffect(() => {
    if (!cloudReady || !isLoggedIn) return;
    let ownUserId: string | null = null;
    supabase.auth.getUser().then(({ data }) => { ownUserId = data.user?.id || null; });
    const channel = supabase
      .channel('shared-app-state')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'app_state', filter: 'id=eq.1' }, (event: any) => {
        if (event.new?.updated_by && event.new.updated_by === ownUserId) return;
        const payload = event.new?.payload;
        if (!payload) return;
        skipCloudWriteRef.current = true;
        if (payload.settings) {
          const localToken = storage.getSettings()?.profile?.token || '';
          setSettings({ ...payload.settings, profile: { ...payload.settings.profile, token: localToken } });
        }
        if (Array.isArray(payload.messages)) setMessages(payload.messages);
        if (Array.isArray(payload.users)) setUsers(payload.users);
        if (Array.isArray(payload.broadcasts)) setBroadcasts(payload.broadcasts);
        if (Array.isArray(payload.analytics)) setAnalytics(payload.analytics);
        
      })
      .subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [cloudReady, isLoggedIn]);

  useEffect(() => {
    usersRef.current = users;
  }, [users]);

  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);

  const addTelegramLog = (text: string, type: 'info' | 'message' | 'callback') => {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setTelegramLogs((prev) => [{ id: `log_${Date.now()}_${Math.random().toString(36).substring(7)}`, time, text, type }, ...prev.slice(0, 39)]);
  };

  // Active simulated user
  const defaultSimUser: UserSubscriber = {
    id: 'sim_default',
    telegramId: '98210341',
    name: 'Simulator Customer',
    username: '@simulator_user',
    customerType: 'new',
    phone: '+91 98765 43210',
    joinedAt: 'Just now',
    lastActiveAt: 'Just now',
    totalInteractions: 0,
    tags: ['Simulator'],
    status: 'active',
    avatarColor: '#0284C7',
    unreadCount: 0,
  };
  const currentUser = users[0] || defaultSimUser;

  // Save changes to storage whenever they change
  useEffect(() => {
    storage.saveSettings(settings);
  }, [settings]);

  useEffect(() => {
    storage.saveMessages(messages);
  }, [messages]);

  useEffect(() => {
    storage.saveUsers(users);
  }, [users]);

  useEffect(() => {
    storage.saveBroadcasts(broadcasts);
  }, [broadcasts]);

  useEffect(() => {
    storage.saveAnalytics(analytics);
  }, [analytics]);

  useEffect(() => {
    storage.saveStaff(staffList);
  }, [staffList]);

  // Clean separation of customer chats: tag unassociated messages to correct customer
  useEffect(() => {
    let hasChanges = false;
    const updatedMessages = messages.map((m) => {
      if (m.userId && m.telegramId) return m;

      // Match by phone number in contactData
      if (m.contactData?.phoneNumber) {
        const cleanMsgPhone = m.contactData.phoneNumber.replace(/[^0-9]/g, '');
        const matchedUser = users.find((u) => {
          if (!u.phone) return false;
          const cleanUserPhone = u.phone.replace(/[^0-9]/g, '');
          return cleanMsgPhone === cleanUserPhone || cleanMsgPhone.endsWith(cleanUserPhone) || cleanUserPhone.endsWith(cleanMsgPhone);
        });
        if (matchedUser) {
          hasChanges = true;
          return {
            ...m,
            userId: matchedUser.id,
            telegramId: matchedUser.telegramId,
            userName: matchedUser.name,
          };
        }
      }

      // Match by phone number in text
      if (m.text && m.text.includes('Shared contact:')) {
        const cleanMsgPhone = m.text.replace(/[^0-9]/g, '');
        const matchedUser = users.find((u) => {
          if (!u.phone) return false;
          const cleanUserPhone = u.phone.replace(/[^0-9]/g, '');
          return cleanMsgPhone === cleanUserPhone || cleanMsgPhone.endsWith(cleanUserPhone) || cleanUserPhone.endsWith(cleanMsgPhone);
        });
        if (matchedUser) {
          hasChanges = true;
          return {
            ...m,
            userId: matchedUser.id,
            telegramId: matchedUser.telegramId,
            userName: matchedUser.name,
          };
        }
      }

      return m;
    });

    if (hasChanges) {
      setMessages(updatedMessages);
    }
  }, [users]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Helper to format current time like '04:37 PM'
  const getCurrentFormattedTime = () => {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const triggerInteractionNotification = (
    notif: Omit<InteractionNotification, 'id' | 'timestamp'>
  ) => {
    const timestamp = getCurrentFormattedTime();
    const newNotif: InteractionNotification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(7)}`,
      timestamp,
      ...notif,
    };

    setActivePopupNotification(newNotif);
    setNotificationsHistory((prev) => [newNotif, ...prev.slice(0, 29)]);

    if (settings.soundEnabled) {
      sound.playReceive();
    }

    // Auto-dismiss popup after 8 seconds
    setTimeout(() => {
      setActivePopupNotification((curr) => (curr?.id === newNotif.id ? null : curr));
    }, 8000);
  };

  const handleOpenChatFromNotification = (userId: string) => {
    setCurrentTab('users');
    const targetUser = users.find((u) => u.id === userId || u.telegramId === userId);
    if (targetUser) {
      setSelectedUserForChat(targetUser);
    }
    if (viewMode === 'bot-only') {
      setViewMode('split');
    }
  };

  const enableDesktopNotifications = async () => {
    if (!(typeof window !== 'undefined' && 'Notification' in window)) {
      showToast('Desktop notifications are not supported by this browser.');
      return;
    }
    const permission = Notification.permission === 'default'
      ? await Notification.requestPermission()
      : Notification.permission;
    const enabled = permission === 'granted';
    setDesktopNotificationsEnabled(enabled);
    showToast(enabled ? 'Desktop notifications enabled.' : 'Notifications are blocked. Allow them in your browser site settings.');
  };

  const showDesktopMessageNotification = (senderName: string, messageText: string, userId: string) => {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    try {
      const notification = new Notification(`New Telegram message from ${senderName}`, {
        body: messageText || 'Sent a photo, video, or attachment',
        icon: '/favicon.ico',
        tag: `chatguru-message-${userId}`,
        renotify: true,
      });
      notification.onclick = () => {
        window.focus();
        handleOpenChatFromNotification(userId);
        notification.close();
      };
    } catch (error) {
      console.warn('Could not show desktop notification:', error);
    }
  };

  // Telegram updates are received centrally by the Netlify webhook and fanned out
  // to every signed-in dashboard through Supabase Realtime. The browser must not
  // call getUpdates: Telegram only permits one competing long-polling consumer.
  useEffect(() => {
    if (!cloudReady || !isLoggedIn) {
      setIsTelegramPolling(false);
      return;
    }

    let alive = true;
    const applyTelegramRow = (row: any) => {
      if (!alive || !row?.id || !row?.chat_id) return;
      const chatId = String(row.chat_id);
      const userId = `tg_${chatId}`;
      const timestamp = row.telegram_date
        ? new Date(row.telegram_date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        : getCurrentFormattedTime();
      const mapped: ChatMessage = {
        id: String(row.id),
        userId,
        telegramId: chatId,
        userName: row.sender_name || 'Telegram user',
        sender: row.direction === 'outgoing' ? 'admin' : 'user',
        text: row.message_text || '',
        timestamp,
        status: row.direction === 'outgoing' ? 'sent' : 'delivered',
      };
      setMessages((prev) => prev.some((message) => message.id === mapped.id) ? prev : [...prev, mapped]);

      if (row.direction === 'incoming') {
        const senderName = row.sender_name || 'Telegram user';
        setUsers((prev) => {
          const existing = prev.find((user) => user.telegramId === chatId);
          if (existing) {
            return prev.map((user) => user.telegramId === chatId
              ? { ...user, lastActiveAt: 'Just now', totalInteractions: user.totalInteractions + 1, unreadCount: (user.unreadCount || 0) + 1 }
              : user);
          }
          const created: UserSubscriber = {
            id: userId,
            telegramId: chatId,
            name: senderName,
            username: row.sender_username ? `@${row.sender_username}` : senderName,
            customerType: 'new',
            joinedAt: 'Just now',
            lastActiveAt: 'Just now',
            totalInteractions: 1,
            lastClickedButton: row.message_text || '',
            tags: ['Telegram'],
            status: 'active',
            avatarColor: '#2AABEE',
            unreadCount: 1,
          };
          return [created, ...prev];
        });
        if (row.message_text) showDesktopMessageNotification(senderName, row.message_text, userId);
      }
    };

    const loadRecent = async () => {
      const { data, error } = await supabase
        .from('telegram_messages')
        .select('*')
        .order('created_at', { ascending: true })
        .limit(500);
      if (error) {
        addTelegramLog(`Could not load shared Telegram messages: ${error.message}`, 'info');
        return;
      }
      (data || []).forEach(applyTelegramRow);
    };

    void loadRecent();
    const channel = supabase
      .channel('chatguru-telegram-messages')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'telegram_messages' }, (payload: any) => {
        applyTelegramRow(payload.new);
        if (payload.new?.direction === 'incoming') {
          addTelegramLog(`[Received] ${payload.new.sender_name || 'Telegram user'}: ${(payload.new.message_text || '').slice(0, 100)}`, 'message');
        }
      })
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          setIsTelegramPolling(true);
          addTelegramLog('Connected to shared Telegram inbox via Supabase Realtime.', 'info');
        }
      });

    return () => {
      alive = false;
      setIsTelegramPolling(false);
      void supabase.removeChannel(channel);
    };
  }, [cloudReady, isLoggedIn]);

  // Bot response dispatcher
  const handleUserSendMessage = (
    text: string,
    sender: 'user' | 'bot' | 'admin' = 'user',
    extra?: Partial<ChatMessage>
  ) => {
    const timestamp = getCurrentFormattedTime();
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(7)}`,
      sender,
      text,
      timestamp,
      status: 'read',
      ...extra,
    };

    setMessages((prev) => [...prev, newMsg]);

    if (sender === 'user') {
      // If contact was auto-shared from Telegram ID, update CRM immediately
      if (extra?.isContactCard && extra.contactData?.phoneNumber) {
        const phone = extra.contactData.phoneNumber;
        setUsers((prev) =>
          prev.map((u) =>
            u.id === currentUser.id
              ? {
                  ...u,
                  phone,
                  isPhoneVerified: true,
                  lastActiveAt: 'Just now',
                  activityTimeline: [
                    ...(u.activityTimeline || []),
                    {
                      id: `act_${Date.now()}`,
                      timestamp: 'Just now',
                      action: `Verified phone number auto-shared: ${phone}`,
                      type: 'contact_shared',
                    },
                  ],
                }
              : u
          )
        );
        showToast(`Phone number ${phone} automatically pushed to CRM!`);
        triggerInteractionNotification({
          userName: currentUser.name,
          userUsername: currentUser.username,
          userTelegramId: currentUser.telegramId,
          actionText: `Shared verified phone: ${phone}`,
          type: 'contact_shared',
          phoneNumber: phone,
          userId: currentUser.id,
        });
      } else if (text.trim() === '/start') {
        triggerInteractionNotification({
          userName: currentUser.name,
          userUsername: currentUser.username,
          userTelegramId: currentUser.telegramId,
          actionText: 'Sent /start (Welcome banner & buttons displayed)',
          type: 'start',
          userId: currentUser.id,
        });
      } else {
        triggerInteractionNotification({
          userName: currentUser.name,
          userUsername: currentUser.username,
          userTelegramId: currentUser.telegramId,
          actionText: `Sent message: "${text.slice(0, 45)}"`,
          type: 'message',
          userId: currentUser.id,
        });
      }

      // Update current user interactions in CRM
      setUsers((prev) =>
        prev.map((u) =>
          u.id === currentUser.id
            ? {
                ...u,
                totalInteractions: u.totalInteractions + 1,
                lastActiveAt: 'Just now',
              }
            : u
        )
      );

      // Handle /start command
      if (text.trim() === '/start') {
        const hasSharedPhoneAlready = !!(
          (currentUser.phone && currentUser.phone.trim().length > 0) ||
          currentUser.isPhoneVerified ||
          currentUser.customerType === 'existing' ||
          messages.some(
            (m) =>
              (m.userId === currentUser.id || m.telegramId === currentUser.telegramId) &&
              (m.isContactCard || (m.text && m.text.includes('Shared contact:')))
          )
        );

        if (hasSharedPhoneAlready) {
          // Categorise as an existing client!
          setUsers((prev) =>
            prev.map((u) =>
              u.id === currentUser.id
                ? {
                    ...u,
                    customerType: 'existing',
                    lastActiveAt: 'Just now',
                    totalInteractions: (u.totalInteractions || 0) + 1,
                    activityTimeline: [
                      ...(u.activityTimeline || []),
                      {
                        id: `act_${Date.now()}`,
                        timestamp: 'Just now',
                        action: 'Sent /start (Categorised as Existing Client with shared phone)',
                        type: 'start',
                      },
                    ],
                  }
                : u
            )
          );

          triggerInteractionNotification({
            userName: currentUser.name,
            userUsername: currentUser.username,
            userTelegramId: currentUser.telegramId,
            actionText: 'Sent /start (Existing client - Personal touch greeting)',
            type: 'start',
            phoneNumber: currentUser.phone,
            userId: currentUser.id,
          });

          setIsBotTyping(true);
          setTimeout(() => {
            setIsBotTyping(false);
            const existingClientMsg: ChatMessage = {
              id: `msg_existing_${Date.now()}`,
              userId: currentUser.id,
              telegramId: currentUser.telegramId,
              userName: currentUser.name,
              sender: 'bot',
              // We do NOT share him the welcome banner rather we will share him:
              text: 'hii  sir aap humse already  touch mein hai aaj aapki kya help karein',
              buttons: settings.buttons,
              timestamp: getCurrentFormattedTime(),
              status: 'read',
            };
            setMessages((prev) => [...prev, existingClientMsg]);
            if (settings.soundEnabled) sound.playReceive();
          }, 500);
          return;
        }

        // New client without shared phone: deliver configured welcome poster banner & buttons
        setIsBotTyping(true);
        setTimeout(() => {
          setIsBotTyping(false);
          const welcomeMsg: ChatMessage = {
            id: `msg_welcome_${Date.now()}`,
            userId: currentUser.id,
            telegramId: currentUser.telegramId,
            userName: currentUser.name,
            sender: 'bot',
            imageUrl: settings.poster.showWelcomeBanner !== false ? settings.poster.imageUrl : undefined,
            text: `${settings.poster.title || ''}\n${settings.poster.description || settings.poster.caption || ''}`.trim(),
            buttons: settings.buttons,
            timestamp: getCurrentFormattedTime(),
            status: 'read',
          };
          setMessages((prev) => [...prev, welcomeMsg]);
          if (settings.soundEnabled) sound.playReceive();
        }, 500);
        return;
      }

      // Handle /help or other commands
      if (text.trim() === '/help') {
        setIsBotTyping(true);
        setTimeout(() => {
          setIsBotTyping(false);
          const helpMsg: ChatMessage = {
            id: `msg_help_${Date.now()}`,
            sender: 'bot',
            text: `ℹ️ Need assistance with Winfix by Vikrant Exchange?\n\n• For Self-Service Account: ${settings.about.registerUrl}\n• For 24/7 WhatsApp VIP ID: ${settings.about.whatsappUrl1}\n• Or reply with your query right here and our admin will assist you!`,
            timestamp: getCurrentFormattedTime(),
            status: 'read',
          };
          setMessages((prev) => [...prev, helpMsg]);
          if (settings.soundEnabled) sound.playReceive();
        }, 400);
        return;
      }

      // Keyword smart auto-replies
      const lower = text.toLowerCase();
      setIsBotTyping(true);
      setTimeout(() => {
        setIsBotTyping(false);
        let replyContent = `Thank you for your message! Our customer agent has received your request.\n\nFor instant priority service on WhatsApp: ${settings.about.whatsappUrl1}`;

        if (lower.includes('bonus') || lower.includes('10%') || lower.includes('50%')) {
          replyContent = `🎁 Exclusive Bonus Offer Active!\n\n• 10% Extra on First Deposit\n• 50% Haar-Jeet Cashback on Cricket BLAST matches\n\nRegister now to claim: ${settings.about.registerUrl}`;
        } else if (lower.includes('id') || lower.includes('whatsapp') || lower.includes('support')) {
          replyContent = `📲 Connect with our verified WhatsApp VIP Manager:\n👉 ${settings.about.whatsappUrl1}\n\nOur team is available 24/7 to issue your ID in under 1 minute!`;
        } else if (lower.includes('register') || lower.includes('link') || lower.includes('website')) {
          replyContent = `💎 Official Winfix Auto-Registration Portal:\n👉 ${settings.about.registerUrl}\n\nSelf-deposit and automatic cashout active.`;
        }

        const autoReply: ChatMessage = {
          id: `msg_reply_${Date.now()}`,
          sender: 'bot',
          text: replyContent,
          timestamp: getCurrentFormattedTime(),
          status: 'read',
        };
        setMessages((prev) => [...prev, autoReply]);
        if (settings.soundEnabled) sound.playReceive();
      }, 700);
    }
  };

  // Button clicks from inline keyboard
  const handleButtonClick = (button: InlineButtonConfig) => {
    const timestamp = getCurrentFormattedTime();

    // Track analytics
    const clickType =
      button.callbackKey === 'existing_customer'
        ? 'existing_customer'
        : button.callbackKey === 'new_customer'
        ? 'new_customer'
        : button.actionType === 'whatsapp'
        ? 'whatsapp'
        : button.actionType === 'url'
        ? 'register_url'
        : 'custom';

    const newAnalyticEvent: ClickAnalytics = {
      id: `ev_${Date.now()}`,
      buttonId: button.id,
      buttonLabel: `${button.emoji || ''} ${button.label}`.trim(),
      userId: currentUser.id,
      timestamp: `Today, ${timestamp}`,
      type: clickType,
    };
    setAnalytics((prev) => [newAnalyticEvent, ...prev]);

    triggerInteractionNotification({
      userName: currentUser.name,
      userUsername: currentUser.username,
      userTelegramId: currentUser.telegramId,
      actionText: `Tapped button: "${button.label}"`,
      type: 'button_click',
      userId: currentUser.id,
    });

    // Update user in CRM
    setUsers((prev) =>
      prev.map((u) =>
        u.id === currentUser.id
          ? {
              ...u,
              lastClickedButton: `${button.emoji || ''} ${button.label}`.trim(),
              lastActiveAt: 'Just now',
              totalInteractions: u.totalInteractions + 1,
              customerType:
                button.callbackKey === 'new_customer'
                  ? 'new'
                  : button.callbackKey === 'existing_customer'
                  ? 'existing'
                  : u.customerType,
            }
          : u
      )
    );

    // If it's a URL or WhatsApp action, open in new tab
    if (button.actionType === 'url' || button.actionType === 'whatsapp') {
      if (button.url) {
        window.open(button.url, '_blank', 'noopener,noreferrer');
        showToast(`Redirecting to ${button.url}`);
      }
      return;
    }

    // Callback flow: Send message as user, then bot answers
    const userMsg: ChatMessage = {
      id: `msg_btn_${Date.now()}`,
      sender: 'user',
      text: `${button.emoji || ''} ${button.label}`.trim(),
      timestamp,
      status: 'read',
    };
    setMessages((prev) => [...prev, userMsg]);

    setIsBotTyping(true);
    setTimeout(() => {
      setIsBotTyping(false);
      const botResponse: ChatMessage = {
        id: `msg_resp_${Date.now()}`,
        sender: 'bot',
        text: button.responseText || `You selected: ${button.label}`,
        timestamp: getCurrentFormattedTime(),
        status: 'read',
      };
      setMessages((prev) => [...prev, botResponse]);
      if (settings.soundEnabled) sound.playReceive();
    }, 450);
  };

  // Link clicks on About card
  const handleLinkClick = (url: string, type: 'register_url' | 'whatsapp') => {
    const newAnalyticEvent: ClickAnalytics = {
      id: `ev_link_${Date.now()}`,
      buttonId: type,
      buttonLabel: type === 'whatsapp' ? 'WhatsApp Link' : 'Register URL',
      userId: currentUser.id,
      timestamp: `Today, ${getCurrentFormattedTime()}`,
      type,
    };
    setAnalytics((prev) => [newAnalyticEvent, ...prev]);
    window.open(url, '_blank', 'noopener,noreferrer');
    showToast(`Opening ${url}`);
  };

  // Restart bot
  const handleRestartBot = () => {
    handleUserSendMessage('/start', 'user');
  };

  // Clear chat
  const handleClearChat = () => {
    setMessages([]);
    showToast('Chat history cleared. Send /start to begin.');
  };

  // Admin sending a direct message to a user
  const handleSendAdminMessage = async (userId: string, text: string) => {
    const timestamp = getCurrentFormattedTime();
    const targetUser = users.find((u) => u.id === userId || u.telegramId === userId);
    const adminMsg: ChatMessage = {
      id: `msg_admin_${Date.now()}`,
      userId: targetUser ? targetUser.id : userId,
      telegramId: targetUser?.telegramId,
      userName: targetUser?.name,
      sender: 'admin',
      text,
      timestamp,
      status: 'sent',
    };
    setMessages((prev) => [...prev, adminMsg]);
    if (settings.soundEnabled) sound.playReceive();

    // Only report delivery after Telegram confirms the sendMessage request.
    if (!targetUser?.telegramId) {
      showToast('Message saved in dashboard only: customer Telegram ID is missing.');
      return;
    }
    // The server-side Netlify function owns the bot token; the browser does not need it.
    const result = await telegramApi.sendMessage('', targetUser.telegramId, text);
    if (result.ok) {
      showToast('Telegram confirmed the message was sent.');
      addTelegramLog(`[Delivered] Admin reply sent to ${targetUser.username || targetUser.name}`, 'info');
    } else {
      showToast(`Telegram delivery failed: ${result.description || 'Unknown Telegram API error'}`);
      addTelegramLog(`[Delivery Failed] Admin reply to ${targetUser.username || targetUser.name}: ${result.description || 'Unknown error'}`, 'info');
    }
  };

  // Real Telegram user message received via live listener
  const handleUserJoinedViaTelegram = (user: UserSubscriber, messageText: string) => {
    setUsers((prev) => {
      const exists = prev.find((u) => u.telegramId === user.telegramId);
      if (exists) {
        return prev.map((u) =>
          u.telegramId === user.telegramId
            ? {
                ...u,
                lastActiveAt: 'Just now',
                totalInteractions: u.totalInteractions + 1,
                lastClickedButton: messageText,
              }
            : u
        );
      }
      return [user, ...prev];
    });

    const newMsg: ChatMessage = {
      id: `msg_tg_${Date.now()}`,
      sender: 'user',
      text: messageText,
      timestamp: getCurrentFormattedTime(),
      status: 'read',
    };
    setMessages((prev) => [...prev, newMsg]);
    showToast(`New live message from ${user.name} on Telegram!`);
  };

  // Admin sending a broadcast notification with real Telegram delivery reporting
  const handleSendBroadcast = async (
    broadcast: BroadcastCampaign,
    customChatIds?: string[]
  ): Promise<BroadcastResult> => {
    // Push into active simulator chat so admin sees the immediate effect!
    const broadcastMsg: ChatMessage = {
      id: `msg_bc_${Date.now()}`,
      sender: 'bot',
      imageUrl: broadcast.imageUrl,
      text: `📢 ANNOUNCEMENT:\n\n${broadcast.messageText}`,
      buttons: broadcast.buttons,
      timestamp: getCurrentFormattedTime(),
      status: 'read',
    };
    setMessages((prev: ChatMessage[]) => [...prev, broadcastMsg]);
    if (settings.soundEnabled) sound.playReceive();

    const logs: BroadcastDeliveryLog[] = [];
    let deliveredCount = 0;
    let failedCount = 0;

    // Target recipients: either explicit custom Chat IDs or CRM users with a telegramId
    const targetChatIds: { id: string; name: string }[] = [];

    if (customChatIds && customChatIds.length > 0) {
      customChatIds.forEach((cid) => {
        targetChatIds.push({ id: cid, name: `Chat ${cid}` });
      });
    } else {
      users.forEach((u) => {
        if (u.telegramId && u.telegramId.trim().length > 0) {
          targetChatIds.push({ id: u.telegramId, name: `${u.name} (${u.username || u.telegramId})` });
        }
      });
    }

    if (settings.profile.token && targetChatIds.length > 0) {
      const token = settings.profile.token.trim();

      for (const target of targetChatIds) {
        try {
          let sendResult;
          if (broadcast.imageUrl) {
            sendResult = await telegramApi.sendPhoto(
              token,
              target.id,
              broadcast.imageUrl,
              broadcast.messageText,
              broadcast.buttons
            );
          } else {
            sendResult = await telegramApi.sendMessage(
              token,
              target.id,
              broadcast.messageText,
              broadcast.buttons
            );
          }

          if (sendResult.ok) {
            deliveredCount++;
            logs.push({
              target: target.name,
              chatId: target.id,
              status: ('fallbackToText' in sendResult && sendResult.fallbackToText) ? 'fallback' : 'delivered',
              time: getCurrentFormattedTime(),
            });
          } else {
            failedCount++;
            logs.push({
              target: target.name,
              chatId: target.id,
              status: 'failed',
              error: sendResult.description || 'Failed to dispatch to this Chat ID',
              time: getCurrentFormattedTime(),
            });
          }
        } catch (err) {
          failedCount++;
          logs.push({
            target: target.name,
            chatId: target.id,
            status: 'failed',
            error: err instanceof Error ? err.message : 'Network error connecting to Telegram',
            time: getCurrentFormattedTime(),
          });
        }
      }
    } else if (!settings.profile.token) {
      // Simulator demo delivery
      deliveredCount = 1;
      logs.push({
        target: 'Active Telegram Simulator',
        chatId: 'simulator_1',
        status: 'delivered',
        time: getCurrentFormattedTime(),
      });
    }

    const completedCampaign: BroadcastCampaign = {
      ...broadcast,
      status: failedCount > 0 && deliveredCount === 0 ? 'failed' : 'sent',
      recipientsCount: targetChatIds.length > 0 ? targetChatIds.length : 1,
      deliveredCount,
    };

    setBroadcasts((prev) => [completedCampaign, ...prev]);

    if (failedCount > 0) {
      showToast(`Broadcast finished: ${deliveredCount} delivered, ${failedCount} failed.`);
    } else {
      showToast(`Broadcast delivered to ${deliveredCount} subscriber(s)!`);
    }

    return {
      total: targetChatIds.length > 0 ? targetChatIds.length : 1,
      delivered: deliveredCount,
      failed: failedCount,
      logs,
    };
  };

  // Reset to clean slate
  const handleResetData = () => {
    storage.resetAll();
    setSettings(CLEAN_SETTINGS);
    setMessages(INITIAL_MESSAGES);
    setUsers(INITIAL_USERS);
    setBroadcasts(INITIAL_BROADCASTS);
    setAnalytics(INITIAL_ANALYTICS);
    showToast('Clean slate initialized! All prefilled items removed.');
  };

  // Export JSON backup
  const handleExportData = () => {
    const fullBackup = {
      settings,
      messages,
      users,
      broadcasts,
      analytics,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(fullBackup, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `telebot_backup_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('JSON backup exported successfully.');
  };

  // Import JSON backup
  const handleImportData = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = JSON.parse(content);
        if (parsed.settings) setSettings(parsed.settings);
        if (parsed.messages) setMessages(parsed.messages);
        if (parsed.users) setUsers(parsed.users);
        if (parsed.broadcasts) setBroadcasts(parsed.broadcasts);
        if (parsed.analytics) setAnalytics(parsed.analytics);
        showToast('Configuration imported successfully!');
      } catch {
        showToast('Failed to parse JSON file.');
      }
    };
    reader.readAsText(file);
  };

  // Handle staff logout
  const handleLogout = async () => {
    await supabase.auth.signOut();
    setCloudReady(false);
    setIsLoggedIn(false);
    showToast('Logged out successfully.');
  };

  if (authLoading) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-900 text-white text-sm font-bold">Checking secure staff session…</div>;
  }

  // If staff is not authenticated, display the centralized email/password login portal.
  if (!isLoggedIn) {
    return (
      <LoginScreen
        staffList={staffList}
        botName={settings.profile.name}
        onLoginSuccess={(staff, remember) => {
          setCurrentStaff(staff);
          showToast(`Welcome back, ${staff.name}!`);
        }}
      />
    );
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-100 font-sans text-slate-900 antialiased">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-white border-2 border-slate-900 text-slate-900 px-4 py-2.5 rounded-lg shadow-xl text-xs font-bold flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-sky-600" />
          <span>{toastMessage}</span>
          <button onClick={() => setToastMessage(null)} className="ml-2 text-slate-500 hover:text-slate-900 cursor-pointer">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating Popup Notification on User Bot Interaction */}
      <NotificationPopup
        notification={activePopupNotification}
        onDismiss={() => setActivePopupNotification(null)}
        onOpenChat={handleOpenChatFromNotification}
      />

      {/* Main Content Area based on View Mode */}
      {viewMode === 'bot-only' ? (
        // Fullscreen Telegram Simulator Mode
        <div className="w-full h-full flex flex-col items-center justify-center p-2 sm:p-6 bg-slate-200 relative">
          <button
            onClick={() => setViewMode('split')}
            className="absolute top-4 left-4 z-40 flex items-center gap-2 px-3.5 py-2 bg-slate-900 text-white text-xs font-bold rounded-lg border border-slate-700 hover:bg-black shadow-lg cursor-pointer"
          >
            <LayoutDashboard className="w-4 h-4 text-sky-400" />
            <span>Open Admin Dashboard</span>
          </button>

          <div className="w-full max-w-[430px] h-[92vh] max-h-[880px]">
            <TelegramSimulator
              settings={settings}
              messages={messages}
              onSendMessage={handleUserSendMessage}
              onButtonClick={handleButtonClick}
              onLinkClick={handleLinkClick}
              onRestartBot={handleRestartBot}
              onClearChat={handleClearChat}
              currentUser={currentUser}
              isBotTyping={isBotTyping}
            />
          </div>
        </div>
      ) : (
        // Split or Admin-Only Layout
        <div className="flex w-full h-full overflow-hidden text-slate-900">
          {/* Admin Sidebar */}
          <AdminSidebar
            currentTab={currentTab}
            onSelectTab={setCurrentTab}
            activeUsersCount={users.length}
            unreadMessagesCount={users.filter((u) => (u.unreadCount || 0) > 0).length}
            viewMode={viewMode}
            onSetViewMode={setViewMode}
            currentStaff={currentStaff}
            onOpenStaffPanel={() => setCurrentTab('staff')}
            onLogout={handleLogout}
          />

          {/* Admin Main Body */}
          <div className="flex-1 flex flex-col min-w-0 bg-slate-100 overflow-hidden text-slate-900">
            <AdminHeader
              currentTab={currentTab}
              onResetData={handleResetData}
              onExportData={handleExportData}
              onImportData={handleImportData}
              botName={settings.profile.name}
              subscribersCount={users.length}
              isPollingActive={isTelegramPolling}
              desktopNotificationsEnabled={desktopNotificationsEnabled}
              onEnableDesktopNotifications={enableDesktopNotifications}
              botUsername={settings.profile.username}
              currentStaff={currentStaff}
              onSwitchStaffClick={() => setCurrentTab('staff')}
              notifications={notificationsHistory}
              onOpenChat={handleOpenChatFromNotification}
              onLogout={handleLogout}
            />

            {/* Tab Body with Split Bot on the right if in 'split' mode */}
            <div className="flex-1 flex overflow-hidden">
              <main className="flex-1 overflow-y-auto p-4 sm:p-6 text-slate-900">
                {currentTab === 'overview' && (
                  <OverviewTab
                    settings={settings}
                    users={users}
                    analytics={analytics}
                    broadcasts={broadcasts}
                    onNavigateTab={setCurrentTab}
                    onSelectUserForChat={(u) => setSelectedUserForChat(u)}
                  />
                )}

                {currentTab === 'builder' && (
                  <BotBuilderTab
                    settings={settings}
                    onUpdateSettings={setSettings}
                  />
                )}

                {currentTab === 'users' && (
                  <CrmUsersTab
                    users={users}
                    onUpdateUsers={setUsers}
                    selectedUser={selectedUserForChat}
                    onSelectUser={setSelectedUserForChat}
                    onSendAdminMessage={handleSendAdminMessage}
                    messages={messages}
                    currentStaff={currentStaff}
                    staffList={staffList}
                  />
                )}

                {currentTab === 'broadcast' && (
                  <BroadcastTab
                    broadcasts={broadcasts}
                    onSendBroadcast={handleSendBroadcast}
                    subscribersCount={users.length}
                    users={users}
                    botToken={settings.profile.token}
                  />
                )}

                {currentTab === 'analytics' && (
                  <AnalyticsTab
                    analytics={analytics}
                    users={users}
                  />
                )}

                {currentTab === 'api' && (
                  <TelegramApiTab
                    settings={settings}
                    onUpdateSettings={setSettings}
                    onUserJoinedViaTelegram={handleUserJoinedViaTelegram}
                    isLiveListening={isTelegramPolling}
                    liveLogs={telegramLogs}
                  />
                )}

                {currentTab === 'staff' && (
                  <StaffPanel
                    staffList={staffList}
                    currentStaff={currentStaff}
                    onSelectStaff={(s) => {
                      setCurrentStaff(s);
                      showToast(`Switched active profile to ${s.name} (${s.role.replace('_', ' ')})`);
                    }}
                    onUpdateStaffList={setStaffList}
                  />
                )}
              </main>

              {/* Side-by-Side Live Telegram Simulator (Split View) */}
              {viewMode === 'split' && (
                <div className="hidden xl:flex w-[420px] 2xl:w-[460px] p-4 bg-slate-200/90 border-l border-slate-300 flex-col items-center justify-center shrink-0 text-slate-900">
                  <div className="w-full flex items-center justify-between pb-2 text-xs text-slate-700">
                    <span className="font-extrabold text-slate-900 flex items-center gap-1.5">
                      <Smartphone className="w-3.5 h-3.5 text-sky-600" />
                      Live Telegram Bot Simulator
                    </span>
                    <button
                      onClick={() => setViewMode('bot-only')}
                      className="text-[11px] text-sky-700 font-bold hover:underline cursor-pointer"
                    >
                      Expand Fullscreen
                    </button>
                  </div>

                  <div className="w-full h-full max-h-[820px]">
                    <TelegramSimulator
                      settings={settings}
                      messages={messages}
                      onSendMessage={handleUserSendMessage}
                      onButtonClick={handleButtonClick}
                      onLinkClick={handleLinkClick}
                      onRestartBot={handleRestartBot}
                      onClearChat={handleClearChat}
                      currentUser={currentUser}
                      isBotTyping={isBotTyping}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
