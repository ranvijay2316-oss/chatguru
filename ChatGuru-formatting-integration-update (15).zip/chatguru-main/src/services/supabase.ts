import { createClient } from '@supabase/supabase-js';

// Vite replaces these values at build time. Netlify must have both variables
// configured before the site is built and deployed.
const url = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.trim();
const anonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined)?.trim();

const missing: string[] = [];
if (!url || url.includes('YOUR_PROJECT_ID') || url.includes('example.supabase.co')) {
  missing.push('VITE_SUPABASE_URL');
}
if (!anonKey || anonKey === 'YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY' || anonKey === 'missing-publishable-key') {
  missing.push('VITE_SUPABASE_ANON_KEY');
}

if (missing.length > 0) {
  const message = `Supabase is not configured in this deployment. Missing or placeholder build-time variable(s): ${missing.join(', ')}. Add them in Netlify and trigger a fresh deploy.`;
  console.error(message);
  throw new Error(message);
}

if (!url!.startsWith('https://') || !url!.endsWith('.supabase.co')) {
  throw new Error('VITE_SUPABASE_URL must be the HTTPS Project URL from your Supabase project.');
}

export const supabase = createClient(url!, anonKey!, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});
