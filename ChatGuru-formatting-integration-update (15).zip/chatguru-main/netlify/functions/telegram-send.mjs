import { createClient } from '@supabase/supabase-js';

const json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { 'content-type': 'application/json' },
});

export default async (request) => {
  if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  const authorization = request.headers.get('authorization') || '';
  const jwt = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
  if (!jwt) return json({ error: 'Authentication required' }, 401);

  const url = process.env.SUPABASE_URL;
  const anon = process.env.SUPABASE_ANON_KEY;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!url || !anon || !serviceKey || !token) return json({ error: 'Server is not configured' }, 500);

  const authClient = createClient(url, anon, { auth: { persistSession: false } });
  const { data: authData, error: authError } = await authClient.auth.getUser(jwt);
  if (authError || !authData.user) return json({ error: 'Invalid session' }, 401);

  const admin = createClient(url, serviceKey, { auth: { persistSession: false } });
  const { data: staff, error: staffError } = await admin
    .from('staff_profiles').select('active').eq('user_id', authData.user.id).maybeSingle();
  if (staffError || !staff?.active) return json({ error: 'Active staff access required' }, 403);

  let body;
  try { body = await request.json(); } catch { return json({ error: 'Invalid JSON' }, 400); }
  const chatId = body?.chatId;
  const text = body?.text;
  if (!chatId || typeof text !== 'string' || !text.trim()) return json({ error: 'chatId and text are required' }, 400);
  if (text.length > 4096) return json({ error: 'Telegram text limit is 4096 characters' }, 400);

  const payload = { chat_id: chatId, text, disable_web_page_preview: true };
  if (body.parseMode === 'HTML' || body.parseMode === 'MarkdownV2') payload.parse_mode = body.parseMode;
  if (body.replyMarkup && typeof body.replyMarkup === 'object') payload.reply_markup = body.replyMarkup;

  const tgResponse = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload),
  });
  const result = await tgResponse.json();
  if (!tgResponse.ok || !result.ok) return json({ error: result.description || 'Telegram send failed' }, 502);

  const sent = result.result;
  const { error: saveError } = await admin.from('telegram_messages').upsert({
    id: `tg:${String(sent.chat.id)}:${String(sent.message_id)}`,
    chat_id: String(sent.chat.id),
    message_id: String(sent.message_id),
    direction: 'outgoing',
    sender_name: 'ChatGuru agent',
    message_text: sent.text || text,
    message_html: body.parseMode === 'HTML' ? text : null,
    telegram_date: sent.date ? new Date(sent.date * 1000).toISOString() : new Date().toISOString(),
    agent_id: authData.user.id,
    delivery_status: 'sent',
  }, { onConflict: 'id' });
  if (saveError) console.error('Message sent but CRM save failed:', saveError.message);
  return json({ ok: true, result: sent, saved: !saveError });
};
