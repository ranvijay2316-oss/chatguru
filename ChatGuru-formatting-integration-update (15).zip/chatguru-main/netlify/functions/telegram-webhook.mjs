import { createClient } from '@supabase/supabase-js';

const json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { 'content-type': 'application/json' },
});

export default async (request) => {
  if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  const secret = process.env.TELEGRAM_WEBHOOK_SECRET;
  const supplied = request.headers.get('x-telegram-bot-api-secret-token');
  if (!secret || !supplied || supplied !== secret) return json({ error: 'Unauthorized' }, 401);

  const url = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) return json({ error: 'Server is not configured' }, 500);

  let update;
  try { update = await request.json(); }
  catch { return json({ error: 'Invalid JSON' }, 400); }
  if (!Number.isInteger(update?.update_id)) return json({ error: 'Missing update_id' }, 400);

  const supabase = createClient(url, serviceKey, { auth: { persistSession: false } });
  const message = update.message || update.edited_message || update.channel_post;
  const callback = update.callback_query;
  let row = null;

  if (message?.chat?.id != null) {
    const from = message.from || {};
    const chatId = String(message.chat.id);
    row = {
      id: `tg:${chatId}:${message.message_id}`,
      chat_id: chatId,
      message_id: String(message.message_id),
      direction: 'incoming',
      sender_name: [from.first_name, from.last_name].filter(Boolean).join(' ') || message.chat.title || 'Telegram user',
      sender_username: from.username || message.chat.username || null,
      message_text: message.text || message.caption || (message.contact ? 'Shared a contact' : '[Non-text Telegram message]'),
      telegram_date: message.date ? new Date(message.date * 1000).toISOString() : new Date().toISOString(),
      delivery_status: 'received',
      raw_update: update,
    };
  } else if (callback?.message?.chat?.id != null) {
    const chatId = String(callback.message.chat.id);
    row = {
      id: `tg-callback:${callback.id}`,
      chat_id: chatId,
      message_id: String(callback.message.message_id),
      direction: 'incoming',
      sender_name: callback.from?.first_name || 'Telegram user',
      sender_username: callback.from?.username || null,
      message_text: `[Button click] ${callback.data || ''}`,
      telegram_date: new Date().toISOString(),
      delivery_status: 'received',
      raw_update: update,
    };
  }

  if (row) {
    const { error } = await supabase.from('telegram_messages').upsert(row, { onConflict: 'id', ignoreDuplicates: true });
    if (error) {
      console.error('Supabase message insert failed:', error.message);
      return json({ error: 'Could not persist update' }, 500);
    }
  }

  // Store the update cursor even when the update is not a message, for auditing/idempotency.
  const { error: updateError } = await supabase.from('telegram_updates').upsert({
    update_id: update.update_id,
    received_at: new Date().toISOString(),
    update_type: Object.keys(update).find((key) => key !== 'update_id') || 'unknown',
  }, { onConflict: 'update_id', ignoreDuplicates: true });
  if (updateError) {
    console.error('Supabase update log failed:', updateError.message);
    return json({ error: 'Could not persist update receipt' }, 500);
  }

  return json({ ok: true });
};
