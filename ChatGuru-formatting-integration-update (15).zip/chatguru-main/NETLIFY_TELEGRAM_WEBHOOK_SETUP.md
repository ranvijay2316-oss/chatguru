# ChatGuru integrated Telegram webhook migration

This version moves incoming Telegram updates to one Netlify webhook, distributes stored messages to signed-in dashboards with Supabase Realtime, and routes ordinary text replies through an authenticated Netlify function.

## 1. Supabase

1. Run `supabase/telegram_webhook_schema.sql` in the existing project (if you already ran it, no need to repeat).
2. Confirm `telegram_messages` is enabled in Database -> Replication / Realtime.
3. Keep the existing staff profile and `app_state` policies from `supabase/schema.sql`.

## 2. Netlify environment variables

Set these server-side variables in Site configuration -> Environment variables, then redeploy:

- `SUPABASE_URL`: your Supabase Project URL.
- `SUPABASE_ANON_KEY`: same public anon/publishable key used by `VITE_SUPABASE_ANON_KEY`; used server-side to validate the signed-in user JWT.
- `SUPABASE_SERVICE_ROLE_KEY`: service-role secret; server-side only.
- `TELEGRAM_BOT_TOKEN`: token from BotFather; server-side only.
- `TELEGRAM_WEBHOOK_SECRET`: random 1-256 character string containing only letters, numbers, underscore or hyphen.
- `PUBLIC_SITE_URL`: production Netlify site URL, for example `https://your-site.netlify.app` (no trailing slash).

`BOT_TOKEN_ENCRYPTION_KEY` is not used by this version; the bot token is held in Netlify's server-side environment variable. Do not add it to any `VITE_` variable.

## 3. Deploy and register

Deploy the project to Netlify. Sign in to ChatGuru using the `super_admin` account, open the Telegram API tab, and use the webhook registration action. It calls `/.netlify/functions/telegram-register-webhook`, which verifies the staff session and role before registering the Telegram webhook with the configured secret.

Webhook endpoint: `https://YOUR-SITE.netlify.app/.netlify/functions/telegram-webhook`

## 4. What this version changes

- Removes the two browser `getUpdates` polling loops (App and Telegram API tab).
- Adds a single Telegram webhook receiver with secret-header verification and update/message deduplication.
- Stores incoming Telegram messages in `telegram_messages`.
- Loads recent stored messages and subscribes to Supabase Realtime in the dashboard, so both signed-in computers receive incoming messages.
- Routes ordinary text `sendMessage` calls through the authenticated Netlify function and stores the outgoing copy.
- Adds super-admin-only webhook registration.

## 5. Known remaining limitations (please read)

- The legacy bot token field is still present in the existing settings UI/local browser storage for older bot-management and photo operations. This version does **not** yet complete super-admin token replacement/removal or remove every browser-side Telegram API call.
- Photo sends, contact prompts, callback answers, bot profile changes and existing automatic `/start`/auto-reply/callback workflows are not fully migrated to server functions. The central webhook stores callback events, but the old browser automation handler was removed with polling.
- Telegram does not reliably notify bots when a user deletes a private-chat message. Already stored messages remain in Supabase, but deletions cannot be detected reliably.
- Desktop notifications work only while the dashboard is open and browser notification permission is granted. Closed-browser push needs separate Web Push infrastructure.
- The current application-wide `app_state` is still a whole-workspace snapshot. The new Telegram message table is the shared source for Telegram messages, but other CRM state can still have last-write-wins behavior.

Test with a non-critical Telegram chat first. Confirm the webhook URL using Telegram `getWebhookInfo`, then test incoming and outgoing text messages from both computers before relying on it operationally.


## Agent message formatting

The CRM text reply path now converts common Markdown syntax to Telegram-safe HTML before calling the authenticated `telegram-send` function. It supports **bold**, *italic*, __underline__, ~~strikethrough~~, `inline code`, fenced code blocks, and `[links](https://example.com)`. Existing Telegram HTML tags are passed through. Plain text is sent unchanged.
