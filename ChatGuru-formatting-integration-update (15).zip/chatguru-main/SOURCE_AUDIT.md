# Source-code audit findings

The original archive used `src/services/storage.ts` for all app data:
- `telebot_v5_clean_zero_settings`
- `telebot_v5_clean_zero_messages`
- `telebot_v5_clean_zero_users`
- `telebot_v5_clean_zero_broadcasts`
- `telebot_v5_clean_zero_analytics`
- `telebot_v5_clean_zero_staff`
- `telebot_v5_clean_zero_current_staff`
- `telebot_auth_logged_in_v1`

The original `LoginScreen.tsx` authenticated by comparing a typed password with `StaffMember.password` from the browser's `staffList`, and also contained quick logins `admin/admin123` and `agent/agent123`. The original staff panel displayed and copied passwords. This is not server authentication and cannot synchronize accounts securely.

The patch:
- replaces the login form with Supabase Auth email/password sign-in;
- verifies each authenticated user against `staff_profiles`;
- moves the shared dashboard workspace into Supabase `app_state`;
- subscribes to Supabase Realtime updates for the shared state;
- migrates the owner browser's existing local cache on the first owner login if no shared state exists;
- excludes the Telegram bot token from the shared cloud payload;
- removes demo login credentials and password display from the staff panel;
- changes local reset to remove only this app's keys, not all browser local storage.

The original project also calls Telegram Bot API endpoints directly from the browser and runs Telegram `getUpdates` polling in the browser. That remains a production security/architecture issue and should be moved to a server-side webhook/worker before using the bot with real users.
