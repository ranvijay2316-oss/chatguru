-- ChatGuru shared workspace + staff authentication
-- Run in Supabase SQL Editor as project owner.

create table if not exists public.staff_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  email text not null unique,
  username text,
  role text not null check (role in ('super_admin', 'support_agent', 'marketing_manager')),
  phone text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.app_state (
  id integer primary key check (id = 1),
  payload jsonb not null default '{}'::jsonb,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);

alter table public.staff_profiles enable row level security;
alter table public.app_state enable row level security;

-- SECURITY DEFINER avoids recursive RLS when policies check staff_profiles.
create or replace function public.is_active_chatguru_staff()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.staff_profiles
    where user_id = auth.uid() and active = true
  );
$$;

create or replace function public.is_chatguru_super_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.staff_profiles
    where user_id = auth.uid() and active = true and role = 'super_admin'
  );
$$;

drop policy if exists "Active staff can read staff directory" on public.staff_profiles;
create policy "Active staff can read staff directory"
on public.staff_profiles for select to authenticated
using (public.is_active_chatguru_staff());

drop policy if exists "Super admins can update staff profiles" on public.staff_profiles;
create policy "Super admins can update staff profiles"
on public.staff_profiles for update to authenticated
using (public.is_chatguru_super_admin())
with check (public.is_chatguru_super_admin());

drop policy if exists "Active staff can read shared state" on public.app_state;
create policy "Active staff can read shared state"
on public.app_state for select to authenticated
using (public.is_active_chatguru_staff());

drop policy if exists "Active staff can create shared state" on public.app_state;
create policy "Active staff can create shared state"
on public.app_state for insert to authenticated
with check (public.is_chatguru_super_admin() and updated_by = auth.uid());

drop policy if exists "Active staff can update shared state" on public.app_state;
create policy "Active staff can update shared state"
on public.app_state for update to authenticated
using (public.is_active_chatguru_staff())
with check (public.is_active_chatguru_staff() and updated_by = auth.uid());

grant select on public.staff_profiles to authenticated;
grant update (name, username, role, phone, active) on public.staff_profiles to authenticated;
grant select, insert, update on public.app_state to authenticated;

-- Realtime: in Supabase Dashboard, Database -> Replication, enable app_state
-- in the supabase_realtime publication if it is not already enabled.
