-- Run this in Supabase SQL Editor after the existing ChatGuru schema.sql.
create table if not exists public.telegram_messages (
  id text primary key,
  chat_id text not null,
  message_id text,
  direction text not null check (direction in ('incoming', 'outgoing')),
  sender_name text,
  sender_username text,
  message_text text,
  message_html text,
  telegram_date timestamptz,
  created_at timestamptz not null default now(),
  agent_id uuid references auth.users(id),
  delivery_status text not null default 'received',
  raw_update jsonb
);
create index if not exists telegram_messages_chat_created_idx
  on public.telegram_messages(chat_id, created_at);

create table if not exists public.telegram_updates (
  update_id bigint primary key,
  received_at timestamptz not null default now(),
  update_type text not null
);

alter table public.telegram_messages enable row level security;
alter table public.telegram_updates enable row level security;
drop policy if exists "Active staff can read Telegram messages" on public.telegram_messages;
create policy "Active staff can read Telegram messages"
  on public.telegram_messages for select to authenticated
  using (public.is_active_chatguru_staff());
drop policy if exists "Active staff can read Telegram updates" on public.telegram_updates;
create policy "Active staff can read Telegram updates"
  on public.telegram_updates for select to authenticated
  using (public.is_active_chatguru_staff());
grant select on public.telegram_messages, public.telegram_updates to authenticated;

-- Add telegram_messages to Realtime publication. If already present, ignore the duplicate error.
do $$ begin
  alter publication supabase_realtime add table public.telegram_messages;
exception when duplicate_object then null;
when others then
  if sqlstate <> '42710' then raise; end if;
end $$;
